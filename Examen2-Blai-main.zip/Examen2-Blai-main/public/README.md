# Plantilla FrontEnd con SASS
##### Plantilla Básica para poder empezar casi cualquier proyecto en **FrontEnd**.

~~~
Metodología de carpetas en FrontEnd
Estructura en imágenes (svg, jpg, iconos, etc)
Readme, licencia MIT, gitignore
Fuentes externas al OS
Semiestructuras en código
Comentarios introductorios
PreCompilador SASS
~~~

> Este contenido se ha creado para mís alumnos, que se inician en el maravilloso mundo de la programación.


---
###### _Copyright 2021 - Toni Ferra_